import 'package:flutter/material.dart';

class SensorReadings extends StatelessWidget {
  final double totalPowerConsumption;
  final String timestamp;

  SensorReadings({required this.totalPowerConsumption, required this.timestamp});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Total Power Consumption: $totalPowerConsumption kW'),
          SizedBox(height: 10),
          Text('Sensor Readings:'),
          // Display your sensor readings here. Replace with actual data widgets
          Expanded(
            child: Center(
              child: Image.asset('assets/graph_placeholder.png'), // Placeholder for graph
            ),
          ),
          Text('Timestamp: $timestamp'),
        ],
      ),
    );
  }
}
