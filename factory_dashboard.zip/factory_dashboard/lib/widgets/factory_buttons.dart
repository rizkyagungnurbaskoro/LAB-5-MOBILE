import 'package:flutter/material.dart';

class FactoryButtons extends StatelessWidget {
  final Function(String) onFactorySelected;

  FactoryButtons({required this.onFactorySelected});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          _factoryButton('Factory 1'),
          _factoryButton('Factory 2'),
          _factoryButton('Factory 3'),
          // Add more factory buttons as needed
        ],
      ),
    );
  }

  Widget _factoryButton(String factory) {
    return GestureDetector(
      onTap: () => onFactorySelected(factory),
      child: Container(
        margin: EdgeInsets.all(8.0),
        padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
        decoration: BoxDecoration(
          color: Colors.blue,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Center(
          child: Text(
            factory,
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
    );
  }
}
