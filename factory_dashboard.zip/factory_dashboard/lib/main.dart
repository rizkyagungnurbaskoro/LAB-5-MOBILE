import 'package:flutter/material.dart';
import 'screens/dashboard_screen.dart';
import 'screens/engineer_list_screen.dart';
import '/screens/notifications_settings_screen.dart';
import 'screens/account_activation_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Factory Dashboard',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: DashboardScreen(),
      routes: {
        '/dashboard': (context) => DashboardScreen(),
        '/engineers': (context) => EngineerListScreen(),
        '/notifications': (context) => NotificationSettingsScreen(),
        '/activate': (context) => AccountActivationScreen(),
      },
    );
  }
}
