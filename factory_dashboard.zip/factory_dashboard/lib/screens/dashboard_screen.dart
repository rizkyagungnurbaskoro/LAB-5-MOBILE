import 'package:flutter/material.dart';
import '../../widgets/factory_buttons.dart';
import '../../widgets/sensor_readings.dart';
import '../../widgets/bottom_navigation.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String selectedFactory = 'Factory 2';
  double totalPowerConsumption = 1549.7; // Example value
  String timestamp = '2024-05-28 12:34'; // Example value

  void updateFactory(String factory) {
    setState(() {
      selectedFactory = factory;
      // Update other state variables as needed
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(selectedFactory),
      ),
      body: Column(
        children: [
          FactoryButtons(
            onFactorySelected: updateFactory,
          ),
          Expanded(
            child: SensorReadings(
              totalPowerConsumption: totalPowerConsumption,
              timestamp: timestamp,
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigation(currentIndex: 1),
    );
  }
}
