import 'package:flutter/material.dart';
import '../../widgets/bottom_navigation.dart';

class InvitationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Invitation'),
      ),
      body: Center(
        child: Text('Invitation Screen'),
      ),
      bottomNavigationBar: BottomNavigation(currentIndex: 0),
    );
  }
}
