import 'package:flutter/material.dart';
import '../../widgets/bottom_navigation.dart';

class AccountActivationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Account Activation'),
      ),
      body: Center(
        child: Text('Account Activation Screen'),
      ),
      bottomNavigationBar: BottomNavigation(currentIndex: 1),
    );
  }
}
