import 'package:flutter/material.dart';
import '../../widgets/bottom_navigation.dart';

class EngineerListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Engineer List'),
      ),
      body: Center(
        child: Text('Engineer List Screen'),
      ),
      bottomNavigationBar: BottomNavigation(currentIndex: 0),
    );
  }
}
