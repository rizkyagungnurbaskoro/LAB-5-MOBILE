import 'package:flutter/material.dart';
import '../../widgets/bottom_navigation.dart';

class NotificationSettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notification Settings'),
      ),
      body: Center(
        child: Text('Notification Settings Screen'),
      ),
      bottomNavigationBar: BottomNavigation(currentIndex: 2),
    );
  }
}
